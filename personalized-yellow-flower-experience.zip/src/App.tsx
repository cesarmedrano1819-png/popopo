import { FormEvent, PointerEvent as ReactPointerEvent, useEffect, useMemo, useRef, useState } from "react";

type Petal = { id: number; x: number; y: number; drift: number; delay: number };

const Heart = ({ className = "" }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20.3S3.4 15.2 3.4 8.7A4.6 4.6 0 0 1 12 6.4a4.6 4.6 0 0 1 8.6 2.3c0 6.5-8.6 11.6-8.6 11.6Z" fill="currentColor" /></svg>
);

const Arrow = () => (
  <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h13m-5-5 5 5-5 5" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" /></svg>
);

function safeName(value: string | null, fallback = "") {
  if (!value) return fallback;
  return value.replace(/[<>\u0000-\u001F]/g, "").trim().slice(0, 42);
}

function Creator() {
  const [to, setTo] = useState("");
  const [from, setFrom] = useState("");
  const [link, setLink] = useState("");
  const [copied, setCopied] = useState(false);

  const create = (event: FormEvent) => {
    event.preventDefault();
    const cleanTo = safeName(to);
    if (!cleanTo) return;
    const url = new URL(window.location.href);
    url.search = "";
    url.searchParams.set("para", cleanTo);
    if (safeName(from)) url.searchParams.set("de", safeName(from));
    setLink(url.toString());
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(link);
    } catch {
      const area = document.createElement("textarea");
      area.value = link;
      document.body.appendChild(area);
      area.select();
      document.execCommand("copy");
      area.remove();
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  const whatsapp = `https://wa.me/?text=${encodeURIComponent(`Preparé algo bonito para ti 💛\n\nÁbrelo cuando tengas un momento:\n\n${link}`)}`;

  return (
    <main className="creator-shell">
      <div className="creator-glow" />
      <section className="creator" aria-labelledby="creator-title">
        <div className="creator-mark"><Heart /></div>
        <p className="kicker">Un detalle que florece</p>
        <h1 id="creator-title">Crea un pequeño jardín para alguien especial.</h1>
        <p className="creator-lead">Escribe su nombre. Nosotros nos encargamos de que el amarillo diga todo lo demás.</p>

        {!link ? (
          <form onSubmit={create} className="creator-form">
            <label><span>¿Cómo se llama?</span><input value={to} onChange={(e) => setTo(e.target.value)} placeholder="Valeria" autoFocus maxLength={42} required /></label>
            <label><span>Tu nombre <i>(opcional)</i></span><input value={from} onChange={(e) => setFrom(e.target.value)} placeholder="Juli" maxLength={42} /></label>
            <button className="primary-button" type="submit">Crear su jardín <Arrow /></button>
          </form>
        ) : (
          <div className="garden-ready" aria-live="polite">
            <h2>Su jardín está listo <span aria-hidden="true">🌻</span></h2>
            <p>Un enlace privado, hecho especialmente para {safeName(to)}.</p>
            <button className="primary-button" onClick={copy}>{copied ? "Enlace copiado" : "Copiar link"}</button>
            <div className="ready-actions">
              <a href={link}>Ver sorpresa <Arrow /></a>
              <a href={whatsapp} target="_blank" rel="noreferrer">Enviar por WhatsApp <Arrow /></a>
            </div>
            <button className="start-over" onClick={() => setLink("")}>Crear otro jardín</button>
          </div>
        )}
      </section>
      <p className="creator-signature">Jardines amarillos, hechos para una sola persona.</p>
    </main>
  );
}

function Garden({ to, from }: { to: string; from: string }) {
  const [phase, setPhase] = useState(0);
  const [note, setNote] = useState(false);
  const [petals, setPetals] = useState<Petal[]>([]);
  const stageRef = useRef<HTMLElement>(null);
  const reduced = useMemo(() => window.matchMedia("(prefers-reduced-motion: reduce)").matches, []);
  const memory = (navigator as Navigator & { deviceMemory?: number }).deviceMemory ?? 8;
  const quality = reduced || navigator.hardwareConcurrency <= 4 || memory <= 4 ? "light" : "premium";

  useEffect(() => {
    const timings = reduced ? [150, 900, 1800, 2800, 4600] : [1100, 3000, 6100, 8500, 16000];
    const timers = timings.map((time, index) => window.setTimeout(() => setPhase(index + 1), time));
    return () => timers.forEach(window.clearTimeout);
  }, [reduced]);

  useEffect(() => {
    const handler = (event: DeviceOrientationEvent) => {
      if (!stageRef.current || !event.gamma || quality === "light") return;
      stageRef.current.style.setProperty("--mx", `${Math.max(-12, Math.min(12, event.gamma / 3))}px`);
      stageRef.current.style.setProperty("--my", `${Math.max(-8, Math.min(8, (event.beta ?? 0) / 8))}px`);
    };
    window.addEventListener("deviceorientation", handler, { passive: true });
    return () => window.removeEventListener("deviceorientation", handler);
  }, [quality]);

  const parallax = (event: ReactPointerEvent<HTMLElement>) => {
    if (quality === "light" || event.pointerType !== "mouse") return;
    const x = (event.clientX / window.innerWidth - 0.5) * 20;
    const y = (event.clientY / window.innerHeight - 0.5) * 14;
    stageRef.current?.style.setProperty("--mx", `${x}px`);
    stageRef.current?.style.setProperty("--my", `${y}px`);
  };

  const releasePetals = (event: ReactPointerEvent, count = 5) => {
    const rect = stageRef.current?.getBoundingClientRect();
    if (!rect) return;
    const created = Array.from({ length: quality === "light" ? Math.min(2, count) : count }, (_, index) => ({
      id: Date.now() + index,
      x: event.clientX - rect.left + (index - count / 2) * 9,
      y: event.clientY - rect.top,
      drift: (index % 2 ? 1 : -1) * (28 + index * 7),
      delay: index * 0.07,
    }));
    setPetals((current) => [...current.slice(-8), ...created]);
    window.setTimeout(() => setPetals((current) => current.filter((p) => !created.some((c) => c.id === p.id))), 2600);
  };

  const touchBouquet = (event: ReactPointerEvent) => {
    releasePetals(event, 7);
    setNote(true);
    window.setTimeout(() => setNote(false), 2300);
  };

  return (
    <main ref={stageRef} onPointerMove={parallax} className={`garden-stage phase-${phase}`} data-quality={quality}>
      <div className="warm-light" /><div className="grain" />
      <div className="sparkles" aria-hidden="true">{Array.from({ length: quality === "premium" ? 13 : 5 }).map((_, i) => <i key={i} style={{ "--i": i } as React.CSSProperties} />)}</div>
      <div className="opening" aria-hidden={phase > 1}><span>Algo floreció para ti…</span></div>
      <div className="garden-frame frame-back" aria-hidden="true" />
      <button className="edge-bloom edge-one" onPointerDown={(e) => releasePetals(e, 2)} aria-label="Tocar una flor"><img src="/images/single-bloom.jpg" alt="" /></button>
      <button className="edge-bloom edge-two" onPointerDown={(e) => releasePetals(e, 2)} aria-label="Tocar una flor"><img src="/images/single-bloom.jpg" alt="" /></button>

      <section className="name-reveal" aria-label={`Un jardín para ${to}`}>
        <p className="for-label">Para</p><h1>{to}</h1><Heart className="name-heart" /><p className="for-you">Estas flores amarillas son para ti.</p>
      </section>

      <div className="bouquet-wrap">
        <button className="bouquet-button" onPointerDown={touchBouquet} aria-label="Toca el ramo"><span className="bouquet-halo" /><img src="/images/yellow-bouquet.jpg" alt="Ramo de girasoles, rosas y flores amarillas" fetchPriority="high" /></button>
        <p className={`bouquet-note ${note ? "is-visible" : ""}`}>Son todas para ti <Heart /></p><p className="touch-hint">Toca las flores</p>
      </div>

      <section className="message-sequence" aria-live="polite">
        <p>Para ti, {to}.</p><p>No hacía falta una fecha especial.</p><p>Solo una razón para recordarte que alguien pensó en ti.</p><p>Y quiso llenarte el día de amarillo.</p>
      </section>

      <section className="finale">
        <p className="final-kicker">Un jardín solo para ti</p><h2>{to}</h2><span>Que nunca te falten motivos para florecer.</span>{from && <p>Con cariño, {from}</p>}<Heart className="final-heart" />
      </section>

      <div className="petal-layer" aria-hidden="true">{petals.map((petal) => <i key={petal.id} style={{ left: petal.x, top: petal.y, "--drift": `${petal.drift}px`, animationDelay: `${petal.delay}s` } as React.CSSProperties} />)}</div>
      {phase >= 5 && <button className="replay" onClick={() => window.location.reload()} aria-label="Volver a ver la experiencia">Volver a sentirlo</button>}
    </main>
  );
}

export default function App() {
  const params = new URLSearchParams(window.location.search);
  const to = safeName(params.get("para"));
  const from = safeName(params.get("de"));
  return to ? <Garden to={to} from={from} /> : <Creator />;
}